export default {
  data: {
    data: [
      {value:20,name:"北京"},
      {value:60,name:"包头"},
      {value:100,name:"长春"},
      {value:20,name:"大连"},
      {value:80,name:"上海"},
      {value:70,name:"南昌"},
      {value:40,name:"重庆"},
      {value:30,name:"南宁"},
      {value:10,name:"广州"},
      {value:40,name:"拉萨"}
    ]
  }
}