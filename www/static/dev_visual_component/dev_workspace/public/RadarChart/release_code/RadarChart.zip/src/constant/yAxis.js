/**
 * @description 集中存放部分yAxis的常量以及配置项
 */

/**
 * @description 枚举yAxis位置
 */
export const YAXISPOSITION = {
  left: '左方',
  right: '右方'
}