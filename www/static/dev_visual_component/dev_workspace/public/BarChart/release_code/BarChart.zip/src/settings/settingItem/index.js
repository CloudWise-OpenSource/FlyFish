export { default as BatchAxis } from './BatchAxis';
export { default as Axis } from './Axis';
export { default as Legend } from './Legend';
export { default as Title } from './Title';
export { default as Extend } from './Extend';
export { default as DataSetting } from './Data';